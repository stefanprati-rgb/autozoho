# core/__init__.py
# Este arquivo torna a pasta 'core' um pacote importável